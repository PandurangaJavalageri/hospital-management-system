﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hospital_Management_System_OO_Programming
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Hospital hospital = new Hospital();

            Ward ward1 = new Ward();
            ward1.WardType=WardType.GeneralUnit;
            ward1.BasicCost = 1000;
            ward1.WardName = "General";
            Patient patient1 = new Patient();
            ward1.patients.Add(patient1);

            Ward ward2 = new Ward();
            ward2.WardType=WardType.IntesiveCareUnit;
            ward2.BasicCost = 5000;
            ward2.WardName = "ICU";
            Patient patient2 = new Patient();
            ward2.patients.Add(patient2);

            Ward ward3= new Ward();
            ward3.WardType= WardType.SurgicalUnit;
            ward3.BasicCost = 1000;
            ward3.WardName = "Surgical";
            Patient patient3 = new Patient();
            ward3.patients.Add(patient3);

            Ward ward4=new Ward();
            ward4.WardType=WardType.PediatricUnit;
            ward4.WardName = "pediatric";
            ward4.BasicCost= 10000;
            Patient patient4 = new Patient();
            ward4.patients.Add(patient4);

            hospital.wards.Add(ward1);
            hospital.wards.Add(ward4);
            hospital.wards.Add(ward3 );
            hospital.wards.Add(ward2);


            Employee employee = new Employee();
            Doctor d1 = new Doctor();
            d1.Speciality = "skin";
            Doctor d2 = new Doctor();
            d2.Speciality = "eye";
            ConsultantDoctor consultantDoctor = new ConsultantDoctor();
            hospital.employees.Add(d1);
            hospital.employees.Add (d2);
            hospital.employees.Add(consultantDoctor);

            Console.WriteLine($"{hospital.getTotalPatientsByWard(ward4 )}");
            Console.WriteLine($"{hospital.GetWardCostByType(WardType.PediatricUnit)}");
            Console.WriteLine($"{hospital.getTotalDoctors()}");
            List<Doctor> list = new List<Doctor>();
            list = hospital.getDoctorsBySpecialization("skin");
            Console.WriteLine(list.Count);
            Console.WriteLine($"{hospital.getTotalPatients()}");
            Console.WriteLine($"{hospital.getTotalConsultants()}");

         
            


            
            

        }
    }
    public class Hospital
    {
        public List<Ward> wards {  get; set; }=new List<Ward>();
        public List<Employee> employees { get; set; } = new List<Employee>();
        public int getTotalPatients()
        {
            int count = 0;
            foreach(Ward ward in wards)
            {
                foreach(Patient patient in ward.patients)
                {
                    count++;
                }
            }
            return count;
        }
        public int getTotalPatientsByWard(Ward ward)
        {
           return ward.patients.Count;
        }
        public int getTotalDoctors()
        {
            int total = 0;
            foreach(Employee emp in employees)
            {
                if (emp as Doctor != null)
                    total++;
            }
            return total;
        }
        public List<Doctor> getDoctorsBySpecialization(string Spec)
        {
            List<Doctor>d=new List<Doctor> ();
            foreach(Employee employee in employees)
            {
                if (employee as Doctor != null && ((Doctor) employee).Speciality == Spec)
                {
                    d.Add((Doctor) employee);
                }
            }
            return d;
        }
        public int getTotalConsultants()
        {
            int count = 0;
            foreach (Employee employee in employees)
            {
                if (employee as Doctor != null && ((Doctor)employee) is InternalDoctor || ((Doctor)employee) is ConsultantDoctor)
                {
                    count++;
                }
            }
            return count;
        }
        public double GetWardCostByType(WardType type)
        {
            foreach(Ward ward in wards)
            {
                if(ward.WardType == type)
                {
                    return ward.GetWardCost();
                }
            }
            return 0;
        }
    }
    
    public class Ward
    {
        public List<Patient> patients { get; set; }=new List<Patient>();
        public string WardName { get; set; }
        public double BasicCost { get; set; }
        public WardType WardType { get; set; }
        public double GetWardCost()
        {
            return BasicCost + WardCostCalculator.findWardCost(BasicCost,WardType);
        }

        
    }
    public class Patient
    {
        public DateTime AdmittedDate { get; set; }
        public List<string> Allergies {  get; set; }=new List<string>();
        public string PatientTime {  get; set; }
        public  Age age {  get; set; }
    }
    public class Person 
    {
        public string Name { get; set; }
        public string Title {  get; set; }
        public  DateTime DateOfBirth { get; set; }
        public string ResidentialAddress {  get; set; }
        public string Gender { get; set; }
        public string Phone {  get; set; }


    }
    public class Employee:Person
    {
        public DateTime DateOfJoin { get; set; }
        public string Education {  get; set; }

    }
    public class Doctor:Employee
    {
        public string Speciality {  get; set; }

    }
    public enum WardType
    {
        IntesiveCareUnit,
        GeneralUnit,
        PediatricUnit,
        SurgicalUnit
    }
    public enum Gender
    {
        male,
        female,
        others
    }
    public enum Age
    {

    }
    public class  InternalDoctor:Doctor
    {
        
    }
    public class ConsultantDoctor:Doctor
    {

    }
    public class Receptionist
    {

    }
    public class Nurse
    {

    }
    public class WardCostCalculator
    {
        public static double  findWardCost(double BasicCost,WardType WardType)
        {
            return 0;
        }
    }

}
